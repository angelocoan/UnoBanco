export class Cliente {
    nome: String;
    cpf: String;
    email: String;
    telefone: String;
    endereco: String;
  }